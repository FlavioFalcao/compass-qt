/**
 * Copyright (c) 2012 Nokia Corporation.
 */

// Holds the current MapPolyLine object.
var currentRoute = null;

// Holds all of the MapPolyLine objects.
var routes = new Array();
